import { Component } from '@angular/core';

@Component({
  selector: 'app-menu1',
  standalone: true,
  imports: [],
  templateUrl: './menu1.component.html',
  styleUrl: './menu1.component.css'
})
export class Menu1Component {

}
